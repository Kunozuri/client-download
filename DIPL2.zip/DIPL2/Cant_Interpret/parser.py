from token import TokenType, Token
from ast_nodes import VarDeclaration, OutputStatement, Variable, Literal, BinaryExpr

class Parser:
    def __init__(self, tokens):
        self.tokens = tokens
        self.current = 0

    def parse(self):
        statements = []
        while not self.match(TokenType.EOF):
            if self.check(TokenType.KEYWORD):
                keyword = self.peek().value
                
                match keyword:
                    case "VAR": 
                        stmt = self.var_declaration()
                    case "OUTPUT":
                        stmt = self.output_statement()
                    case _:
                        raise RuntimeError(f"Unknown keyword: {keyword}")
                
                statements.append(stmt)
            else:
                raise RuntimeError(f"Expected keyword but got: {self.peek().value}")
        
        return statements

    def output_statement(self):
        self.consume_keyword("OUTPUT")
        expr = self.expression()
        return OutputStatement(expr)

    def var_declaration(self):
        self.consume_keyword("VAR")
        names = [self.consume(TokenType.IDENTIFIER).value]

        self.consume(TokenType.ASSIGN)
        expr = self.expression()
        values = [expr]

        self.consume_keyword("AS")
        var_type = self.consume(TokenType.KEYWORD).value

        if isinstance(expr, Literal):
            if var_type == "CHAR" and (not isinstance(expr.value, str) or len(expr.value) != 1):
                raise RuntimeError(f"CHAR type must be a single character, got: {expr.value}")
            if var_type == "STRING" and not isinstance(expr.value, str):
                raise RuntimeError(f"STRING type must be a string literal, got: {expr.value}")

        return VarDeclaration(names, values, var_type)

    #her tools
    def match(self, type_):
        return self.peek().type == type_

    def peek(self):
        return self.tokens[self.current]

    def advance(self):
        tok = self.tokens[self.current]
        self.current += 1
        return tok

    def check(self, token_type):
        if self.is_at_end():
            return False
        return self.peek().type == token_type
    
    def is_at_end(self):
        return self.peek().type == TokenType.EOF

    #help her
    def consume(self, expected_type):
        tok = self.advance()
        if tok.type != expected_type:
            raise RuntimeError(f"Expected {expected_type}, got {tok}")
        return tok

    def consume_keyword(self, expected):
        token = self.advance()
        if token.type != TokenType.KEYWORD or token.value != expected:
            raise RuntimeError(f"Expected keyword {expected}, got {token}")
        return token
    
    #her operation tools
    def expression(self):
        return self.parse_or()

    def parse_or(self):
        expr = self.parse_and()
        while self.match_operator("or"):
            operator = self.previous().value
            right = self.parse_and()
            expr = BinaryExpr(expr, operator, right)
        return expr

    def parse_and(self):
        expr = self.parse_equality()
        while self.match_operator("and"):
            operator = self.previous().value
            right = self.parse_equality()
            expr = BinaryExpr(expr, operator, right)
        return expr

    def parse_equality(self):
        expr = self.parse_comparison()
        while self.match_operator("=", "!=", "=="):
            operator = self.previous().value
            right = self.parse_comparison()
            expr = BinaryExpr(expr, operator, right)
        return expr

    def parse_comparison(self):
        expr = self.parse_term()
        while self.match_operator("<", "<=", ">", ">="):
            operator = self.previous().value
            right = self.parse_term()
            expr = BinaryExpr(expr, operator, right)
        return expr

    def parse_term(self):
        expr = self.parse_factor()
        while self.match_operator("+", "-"):
            operator = self.previous().value
            right = self.parse_factor()
            expr = BinaryExpr(expr, operator, right)
        return expr

    def parse_factor(self):
        expr = self.parse_primary()
        while self.match_operator("*", "/"):
            operator = self.previous().value
            right = self.parse_primary()
            expr = BinaryExpr(expr, operator, right)
        return expr

    def parse_primary(self):
        tok = self.advance()
        if tok.type == TokenType.INTEGER or tok.type == TokenType.BOOLEAN:
            return Literal(tok.value)
        elif tok.type == TokenType.STRING or tok.type == TokenType.CHAR:
            return Literal(tok.value)
        elif tok.type == TokenType.IDENTIFIER:
            return Variable(tok.value)
        else:
            raise RuntimeError(f"Unexpected token in expression: {tok}")

    #help her oparate
    def match_operator(self, *ops):
        if self.check(TokenType.OPERATOR) and self.peek().value in ops:
            self.advance()
            return True
        return False

    def previous(self):
        return self.tokens[self.current - 1]

from ast_nodes import VarDeclaration, OutputStatement, BinaryExpr, Literal, Variable

class Interpreter:
    def __init__(self):
        self.variables = {}
        self.types = {}

    def interpret(self, node):
        if isinstance(node, VarDeclaration):
            self.variable_declaration(node)
        elif isinstance(node, OutputStatement):
            self.output_statement(node)
    
    def output_statement(self, node):
        value = self.evaluate(node.expression)
        print(value)
    
    def variable_declaration(self, node):
        for name, value_node in zip(node.name, node.value):
            value = self.evaluate(value_node)

            if node.var_type == 'INT':
                if not isinstance(value, int):
                    raise TypeError(f"Type mismatch: expected INT but got {type(value).__name__}")

            elif node.var_type == 'BOOL':
                if not isinstance(value, bool):
                    raise TypeError(f"Type mismatch: expected BOOL but got {type(value).__name__}")

            elif node.var_type == 'CHAR':
                if not isinstance(value, str) or len(value) != 1:
                    raise TypeError(f"Type mismatch: expected CHAR but got {value}")

            elif node.var_type == 'STRING':
                if not isinstance(value, str):
                    raise TypeError(f"Type mismatch: expected STRING but got {type(value).__name__}")

            else:
                raise TypeError(f"Unsupported variable type: {node.var_type}")

            self.variables[name] = value
            self.types[name] = node.var_type

    def evaluate(self, expr):
        if isinstance(expr, Literal):
            return expr.value
        elif isinstance(expr, Variable):
            if expr.name not in self.variables:
                raise RuntimeError(f"Undefined variable: {expr.name}")
            return self.variables[expr.name]
        elif isinstance(expr, BinaryExpr):
            left = self.evaluate(expr.left)
            right = self.evaluate(expr.right)
            op = expr.operator

            if op == '+':
                return left + right
            elif op == '-':
                return left - right
            elif op == '*':
                return left * right
            elif op == '/':
                return left / right
            elif op == '<':
                return left < right
            elif op == '<=':
                return left <= right
            elif op == '>':
                return left > right
            elif op == '>=':
                return left >= right
            elif op in ('=', '=='):
                return left == right
            elif op == '!=':
                return left != right
            elif op == 'and':
                return left and right
            elif op == 'or':
                return left or right
            else:
                raise RuntimeError(f"Unknown operator: {op}")
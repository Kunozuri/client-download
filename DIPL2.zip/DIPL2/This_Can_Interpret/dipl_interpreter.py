# this regex 
import re
import sys

class Interpreter:
    def __init__(self):
        self.variables = {}
        self.types = {}
        self.functions = {}
        self.classes = {}
        self.running = False

    def parse_value(self, val):
        val = val.strip()
        if re.match(r'^\d+$', val):
            return int(val)
        elif re.match(r'^\".*\"$', val):
            return val[1:-1]
        elif re.match(r"^\'.*\'$", val):
            return val[1:-1]
        elif val.upper() == "TRUE":
            return True
        elif val.upper() == "FALSE":
            return False
        elif val in self.variables:
            return self.variables[val]
        else:
            raise ValueError(f"Unrecognized value: {val}")

    def declare_vars(self, line):
        match = re.match(r'VAR (.+) AS (INT|CHAR|BOOL)', line)
        if not match:
            return
        decls, vtype = match.groups()
        for part in decls.split(','):
            if '=' in part:
                var, val = map(str.strip, part.split('='))
                parsed_val = self.parse_value(val)
                self.variables[var] = parsed_val
                self.types[var] = vtype
            else:
                var = part.strip()
                self.variables[var] = None
                self.types[var] = vtype

    def eval_expr(self, expr):
        expr = expr.strip()
        expr = re.sub(r'\bAND\b', 'and', expr)
        expr = re.sub(r'\bOR\b', 'or', expr)
        expr = re.sub(r'\bTRUE\b', 'True', expr)
        expr = re.sub(r'\bFALSE\b', 'False', expr)
        expr = expr.replace('<>', '!=')
        
        for var in self.variables:
            expr = re.sub(rf'\b{var}\b', repr(self.variables[var]), expr)
        
        value = eval(expr)

        # 🔧 Fix: Convert float that looks like an int to actual int
        if isinstance(value, float) and value.is_integer():
            value = int(value)
        
        return value


    def handle_input(self, line):
        match = re.match(r'INPUT: (.+)', line)
        if not match:
            return
        vars = [v.strip() for v in match.group(1).split(',')]
        raw = input(', '.join(vars) + ' = ')
        values = [v.strip() for v in raw.split(',')]
        for var, val in zip(vars, values):
            vtype = self.types[var]
            if vtype == 'INT':
                self.variables[var] = int(val)
            elif vtype == 'CHAR':
                self.variables[var] = val.strip("'")
            elif vtype == 'BOOL':
                self.variables[var] = val.upper() == 'TRUE'

    def handle_output(self, line):
        match = re.match(r'OUTPUT: (.+)', line)
        if not match:
            return

        expr = match.group(1).strip()
        parts = [p.strip() for p in expr.split('&')]
        evaluated_parts = []

        for part in parts:
            # If part is a string literal with brackets, keep as is but strip quotes
            if re.match(r'^\".*\"$', part):
                # Remove surrounding quotes
                literal = part[1:-1]
                evaluated_parts.append(literal)
            else:
                # Evaluate variable or expression
                val = self.eval_expr(part)
                # Convert float to int if whole number
                if isinstance(val, float) and val.is_integer():
                    val = int(val)
                evaluated_parts.append(str(val))

        # Join all parts as string
        result = ''.join(evaluated_parts)
    
        def replace_sharp_outside_brackets(text):
            result = []
            inside_brackets = False
            for char in text:
                if char == '[':
                    inside_brackets = True
                    result.append(char)
                elif char == ']':
                    inside_brackets = False
                    result.append(char)
                elif char == '#' and not inside_brackets:
                    result.append('\n')
                else:
                    result.append(char)
            return ''.join(result)

        result = replace_sharp_outside_brackets(result)
        print(result)

    def run(self, lines):
        # Step 1: Handle IMPORT
        i = 0
        while i < len(lines):
            line = lines[i].strip()
            if line.startswith('IMPORT:'):
                imported_file = line.split(':')[1].strip()
                with open(imported_file) as f:
                    imported_code = f.readlines()
                lines = lines[:i] + imported_code + lines[i+1:]
                continue
            i += 1

        # Step 2: Extract FUNCs and CLASSes
        i = 0
        cleaned_lines = []
        while i < len(lines):
            line = lines[i].strip()
            if line.startswith('FUNC '):
                func_name = line.split()[1]
                func_block = []
                i += 1
                while i < len(lines) and lines[i].strip() != 'STOP':
                    func_block.append(lines[i])
                    i += 1
                self.functions[func_name] = func_block
                i += 1  # skip STOP
            elif line.startswith('CLASS '):
                class_name = line.split()[1]
                methods = {}
                i += 1
                while i < len(lines) and lines[i].strip() != 'STOP':
                    inner_line = lines[i].strip()
                    if inner_line.startswith('FUNC '):
                        method_name = inner_line.split()[1]
                        method_block = []
                        i += 1
                        while i < len(lines) and lines[i].strip() != 'STOP':
                            method_block.append(lines[i])
                            i += 1
                        methods[method_name] = method_block
                        i += 1  # skip STOP
                    else:
                        i += 1
                self.classes[class_name] = methods
                i += 1  # skip final STOP for class
            else:
                cleaned_lines.append(lines[i])
                i += 1

        # Step 3: Execute
        i = 0
        while i < len(cleaned_lines):
            line = cleaned_lines[i].strip()
            if not line or line.startswith('~'):
                i += 1
                continue

            if line.startswith('VAR'):
                # If it's class instantiation like "VAR x = NEW ClassName"
                match_new = re.match(r'VAR\s+(\w+)\s*=\s*NEW\s+(\w+)', line)
                if match_new:
                    var, class_name = match_new.groups()
                    if class_name in self.classes:
                        self.variables[var] = {'__class__': class_name}
                        self.types[var] = class_name
                    else:
                        raise Exception(f"Class '{class_name}' not defined.")
                else:
                    # Normal var declarations, delegate to declare_vars
                    self.declare_vars(line)

            elif line == 'START':
                self.running = True
                
            elif line == 'STOP':
                self.running = False
            
            elif self.running:
                if line.startswith('OUTPUT:'):
                    self.handle_output(line)
                    
                elif line.startswith('INPUT:'):
                    self.handle_input(line)
                
                elif line.startswith('WHILE'):
                    match = re.match(r'WHILE\s*\((.+)\)', line)
                    if not match:
                        raise Exception("Invalid WHILE syntax.")
                    condition = match.group(1).strip()

                    # Find the block for the WHILE loop
                    loop_block = []
                    loop_i = i + 1
                    nested = 1
                    while loop_i < len(cleaned_lines):
                        inner_line = cleaned_lines[loop_i].strip()
                        if inner_line == 'START':
                            nested += 1
                        elif inner_line == 'STOP':
                            nested -= 1
                            if nested == 0:
                                break
                        loop_block.append(cleaned_lines[loop_i])
                        loop_i += 1

                    # Execute the loop while the condition holds
                    while self.eval_expr(condition):
                        self.run(loop_block)

                    # Move i to after the END of the WHILE block
                    i = loop_i

                
                elif line.startswith('CALL:'):
                    call = line.split(':')[1].strip()
                    if '.' in call:
                        var, method = call.split('.')
                        var = var.strip()
                        method = method.split('(')[0].strip()
                        if var in self.variables:
                            obj = self.variables[var]
                            if '__class__' in obj:
                                class_name = obj['__class__']
                                if method in self.classes[class_name]:
                                    self.run(self.classes[class_name][method])
                                else:
                                    raise Exception(f"Method '{method}' not found in class '{class_name}'")
                            else:
                                raise Exception(f"Variable '{var}' is not a class instance.")
                        else:
                            raise Exception(f"Variable '{var}' not found.")
                    else:
                        func_name = call.split('(')[0].strip()
                        if func_name in self.functions:
                            self.run(self.functions[func_name])
                        else:
                            raise Exception(f"Function '{func_name}' not defined.")
            
                elif line.startswith('IF '):
                    condition_match = re.match(r'IF\s*\((.+)\)', line)
                    if not condition_match:
                        raise Exception("Invalid IF syntax")
                    
                    condition = condition_match.group(1)
                    result = self.eval_expr(condition)

                    # Save current index to possibly jump over ELSE block
                    if_block_start = i + 1
                    if_block = []
                    
                    # Collect lines inside IF START/STOP
                    while if_block_start < len(cleaned_lines) and cleaned_lines[if_block_start].strip() != 'START':
                        if_block_start += 1
                    if_block_start += 1  # skip START

                    while if_block_start < len(cleaned_lines) and cleaned_lines[if_block_start].strip() != 'STOP':
                        if_block.append(cleaned_lines[if_block_start])
                        if_block_start += 1
                    if_block_end = if_block_start + 1  # skip STOP

                    # Check if ELSE exists
                    has_else = False
                    else_block = []
                    if if_block_end < len(cleaned_lines) and cleaned_lines[if_block_end].strip() == 'ELSE':
                        has_else = True
                        else_block_start = if_block_end + 1
                        if cleaned_lines[else_block_start].strip() == 'START':
                            else_block_start += 1
                        while else_block_start < len(cleaned_lines) and cleaned_lines[else_block_start].strip() != 'STOP':
                            else_block.append(cleaned_lines[else_block_start])
                            else_block_start += 1
                        i = else_block_start + 1  # Move to after ELSE STOP
                    else:
                        i = if_block_end  # Move to after IF STOP

                    # Execute
                    if result:
                        self.run(if_block)
                    elif has_else:
                        self.run(else_block)
                    continue  # skip incrementing i again

                
                elif '=' in line:
                    var, expr = map(str.strip, line.split('=', 1))
                    value = self.eval_expr(expr)
                    self.variables[var] = value
            
            i += 1



            
if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: python interpreter.py <program.txt>")
        sys.exit(1)

    with open(sys.argv[1]) as f:
        code = f.readlines()

    interpreter = Interpreter()
    interpreter.run(code)
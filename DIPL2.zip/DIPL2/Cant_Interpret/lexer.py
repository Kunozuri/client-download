from token import Token, TokenType

class Lexer:
    def __init__(self, source):
        self.source = source
        self.tokens = []
        self.keywords = {'VAR', 'AS', 'TRUE', 'FALSE', 'INT', 'CHAR', 'STRING', 'BOOL', 'START', 'STOP', 'IF', 'ELSE', 'WHILE', 'OUTPUT', 'INPUT'}
        self.current = 0
        self.line = 1
        self.col = 0

    def tokenize(self):
        while self.current < len(self.source):
            char = self.source[self.current]

            if char.isspace():
                if char == '\n':
                    self.line += 1
                    self.col = 0
                self.advance()
                continue

            if char in '+-*/<=>':
                op = char
                next_char = self.peek()

                if char == '<' and next_char in {'>', '='}:
                    op += next_char
                    self.advance()
                elif char == '>' and next_char == '=':
                    op += next_char
                    self.advance()

                if op == '=':
                    self.tokens.append(Token(TokenType.ASSIGN, op, self.line, self.col))
                else:
                    self.tokens.append(Token(TokenType.OPERATOR, op, self.line, self.col))

                self.advance()
                continue

            if char == "'" or char == '"':
                quote_type = char
                self.advance()
                value = ''
                while self.current < len(self.source) and self.source[self.current] != quote_type:
                    value += self.source[self.current]
                    self.advance()
                
                if self.current >= len(self.source):
                    raise SyntaxError(f"Unterminated string or char literal at line {self.line}, col {self.col}")
                
                self.advance()  # skip closing quote

                token_type = (
                    TokenType.CHAR if quote_type == "'" and len(value) == 1 else TokenType.STRING
                )
                self.tokens.append(Token(token_type, value, self.line, self.col))
                continue

            if char.isdigit():
                self.tokens.append(self.number())
                continue

            if char.isalpha() or char == '_':
                self.tokens.append(self.identifier_or_keyword())
                continue
            
            raise SyntaxError(f"Unexpected character '{char}' at line {self.line}, col {self.col}")

        self.tokens.append(Token(TokenType.EOF, None, self.line, self.col))
        return self.tokens

    # her tools
    def advance(self):
        self.current += 1
        self.col += 1

    def peek(self):
        if self.current + 1 < len(self.source):
            return self.source[self.current + 1]
        return '\0'

    # help her
    def string(self, quote_type):
        self.advance()
        value = ''
        while self.current < len(self.source) and self.source[self.current] != quote_type:
            value += self.source[self.current]
            self.advance()
        self.advance()
        return Token(TokenType.STRING if quote_type == '"' else TokenType.CHAR, value, self.line, self.col)

    def number(self):
        value = ''
        while self.current < len(self.source) and self.source[self.current].isdigit():
            value += self.source[self.current]
            self.advance()
        return Token(TokenType.INTEGER, int(value), self.line, self.col)

    def identifier_or_keyword(self):
        value = ''
        while self.current < len(self.source) and (self.source[self.current].isalnum() or self.source[self.current] == '_'):
            value += self.source[self.current]
            self.advance()

        upper_value = value.upper()
        if upper_value in self.keywords:
            if upper_value in {'TRUE', 'FALSE'}:
                return Token(TokenType.BOOLEAN, upper_value == 'TRUE', self.line, self.col)
            return Token(TokenType.KEYWORD, upper_value, self.line, self.col)

        return Token(TokenType.IDENTIFIER, value, self.line, self.col)

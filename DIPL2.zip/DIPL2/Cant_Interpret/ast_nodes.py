class VarDeclaration:
    def __init__(self, name, value, var_type):
        self.name = name            
        self.value = value          
        self.var_type = var_type    

    def __repr__(self):
        return f"VarDeclaration(name={self.name}, value={self.value}, type={self.var_type})"



class Literal:
    def __init__(self, value):
        self.value = value



class Variable:
    def __init__(self, name):
        self.name = name



class OutputStatement:
    def __init__(self, expression):
        self.expression = expression
        
        

class BinaryExpr:
    def __init__(self, left, operator, right):
        self.left = left    
        self.operator = operator
        self.right = right  
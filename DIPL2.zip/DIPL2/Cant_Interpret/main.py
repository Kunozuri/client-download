def main():
    import sys
    from cant_interpret import Interpreter
    from lexer import Lexer
    from parser import Parser

    if len(sys.argv) != 2:
        print("Usage: python cant_interpret.py filename.txt")
        sys.exit(1)

    filename = sys.argv[1]
    with open(filename, 'r') as f:
        source = f.read()

    lexer = Lexer(source)
    tokens = lexer.tokenize()
    parser = Parser(tokens)
    statement = parser.parse()
    
    interpreter = Interpreter()
    for stmt in statement:
        interpreter.interpret(stmt)
                                                                

if __name__ == "__main__":
    main()
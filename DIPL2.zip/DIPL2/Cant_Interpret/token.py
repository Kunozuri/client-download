from enum import Enum, auto

class TokenType(Enum):
    INTEGER = auto()
    STRING = auto()
    CHAR = auto()
    BOOLEAN = auto()
    IDENTIFIER = auto()
    KEYWORD = auto()
    SYMBOL = auto()
    OPERATOR = auto()
    ASSIGN = auto()
    EOF = auto()

class Token:
    def __init__(self, type_, value, line=0, col=0):
        self.type = type_
        self.value = value
        self.line = line
        self.col = col

    def __repr__(self):
        return f'Token({self.type}, {repr(self.value)})'